from django.core.management.base import BaseCommand
from django_otp.plugins.otp_totp.models import TOTPDevice
from django.contrib.auth.models import User

class Command(BaseCommand):
    help = 'Create a TOTP device for a user'

    def add_arguments(self, parser):
        parser.add_argument('username', type=str, help='Username of the user')

    def handle(self, *args, **kwargs):
        username = kwargs['username']
        user = User.objects.get(username=username)
        device = TOTPDevice.objects.create(user=user, name='default')
        self.stdout.write(self.style.SUCCESS(f'Device created for {username}. Scan this URL: {device.config_url}'))
